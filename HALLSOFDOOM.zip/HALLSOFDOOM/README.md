DO NOT STEAL THIS WAD OR I'LL PUT C4 IN YOUR HOUSE AND BLOW YOU UP, AND IT WILL BE PA-WSOME


I plan to make a part 2 with better design and S C R I P T S!


SO YUH